// src/Login.jsx
import React from 'react';
import styled from 'styled-components';
import { useNavigate } from "react-router-dom";
import Logo from '../../components/Logo/Logo';
import InputText from '../../components/Input/InputText';
import Select from '../../components/Seclect/Seclect';
import Button from '../../components/Button/Button';
import InsertReview from '../../components/Modal/InsertReview';
import Kakao from './Kakao';

const MapBtnWrap = styled.div`
  z-index:999;
  position : fixed;
  bottom:2vh;
  right:2vw;
  width:13vw;
`;

const MapHeadWrap = styled.div`
z-index:999;
  width:43%;
  position:fixed;
  top:2vh;
  left:2vw;
  display:flex;
  flex-direction:row;
  align-items:center;
  justify-content: space-between;
  select{
    width:28%;
  }
`;
const InputWrap = styled.div`
  width:100%;
  align-items:center;
  
  .search-form{
    width:100%;
    display:flex;
    flex-direction:row;
    justify-content:space-between;
    .text{
      width:70%;
    }
    .btn{
      width:25%;
    }
  }
`;
const Map = () => {
  const navigate = useNavigate();
  function goHome(){
      navigate("/");
    }
    function doSubmit(){
      let getInput = document.getElementById('map-search-bar').value;
      alert(getInput);
    }
  
  return (
    <>
      <MapHeadWrap>
        <Logo onClick={goHome} style={{width:'16%'}}>Logo</Logo>
        <Select ></Select>
        <InputWrap style={{width:'50%'}}>
        <form className="search-form" onSubmit={doSubmit} autocomplete="off">
          <InputText className="text" id="map-search-bar"></InputText>
          <Button info className="btn">검색</Button>
        </form>
        </InputWrap>
      </MapHeadWrap>
      <Kakao></Kakao>
      <MapBtnWrap>
        <InsertReview></InsertReview>
      </MapBtnWrap>
      
    </>
    
  );
};

export default Map;
