// src/Login.jsx
import React from 'react';
import styled from 'styled-components';
import { useNavigate } from "react-router-dom";
import Logo from '../../components/Logo/Logo';
import Button from '../../components/Button/Button';
import InputText from '../../components/Input/InputText';
import InputPW from '../../components/Input/InputPW';
import InputEmail from '../../components/Input/InputEmail';

const IdLoginWrap = styled.div`
  width:100vw;
  height:90vh;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content: center;
  .input-wrap{
    width:20%;
    input{
      margin-bottom:1vh;
    }
  }
  .id-btn-wrap{
    width:20%;
    button{
      width:100%;
`;

const IdLogin = () => {
  
  const navigate = useNavigate();
  let goHome = () =>{
    navigate("/");
  }
  
  let goSignup = () =>{
    navigate("/signup");
  }
  let SubmitLogin = () => {
    alert('로그인 성공');
    navigate("/");
  }
  return (
      <IdLoginWrap>
        <Logo onClick={goHome} style={{margin:'0 0 1rem 0'}}>Logo</Logo>
        <form autocomplete="off" className='input-wrap'>
          <InputEmail placeholder="이메일" id="userEmail" sign></InputEmail>
          <InputPW placeholder="비밀번호" id="userPW"></InputPW>
        </form>
        <div className='id-btn-wrap'>
          <Button info onClick={SubmitLogin}>로그인</Button>
          <Button cancel onClick={goSignup}>회원가입</Button>
        </div>
      </IdLoginWrap>
  );
};

export default IdLogin;
