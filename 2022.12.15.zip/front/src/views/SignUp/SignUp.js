// src/Login.jsx
import React from 'react';
import styled from 'styled-components';
import { useNavigate } from "react-router-dom";
import Logo from '../../components/Logo/Logo';
import Button from '../../components/Button/Button';
import InputText from '../../components/Input/InputText';
import InputPW from '../../components/Input/InputPW';
import InputEmail from '../../components/Input/InputEmail';
import InputTel from '../../components/Input/InputTel';

const SingupWrap = styled.div`
  width:100vw;
  height:90vh;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content: center;
  .input-wrap{
    width:20%;
    input{
      margin-bottom:1vh;
    }
  }
  .btn-wrap{
    width:20%;
    display:flex;
    flex-direction:row;
    justify-content:space-between;
    button{
      :first-child{
        width:65%;
      }
      :last-child{
        width:32%;
      }
    }
    
  }
`;

const SignUp = () => {
  
  const navigate = useNavigate();
  let goHome = () =>{
    navigate("/");
  }
  let goLogin = () =>{
    navigate("/login");
  }
  let SubmitSign = () => {
    alert('회원가입 성공');
    navigate("/");
  }
  return (
      <SingupWrap>
        <Logo onClick={goHome} style={{margin:'0 0 1rem 0'}}>Logo</Logo>
        <form autocomplete="off" className='input-wrap'>
          <InputEmail autocomplete="off" placeholder="이메일" id="userEmail" sign></InputEmail>
          <InputText placeholder="아이디" id="userId" sign></InputText>
          <InputPW placeholder="비밀번호" id="userPW" sign></InputPW>
          <InputPW placeholder="비밀번호 확인" id="userPWCheck" sign></InputPW>
          <InputTel placeholder="휴대전화" id="userPhoneNum" sign></InputTel>
        </form>
        <div className='btn-wrap'>
          <Button info onClick={SubmitSign}>회원가입</Button>
          <Button cancel onClick={goLogin}>취소</Button>
        </div>
      </SingupWrap>
  );
};

export default SignUp;
