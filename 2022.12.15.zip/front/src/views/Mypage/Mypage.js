import React from 'react';
import styled from 'styled-components';
import Header from '../Main/Header';
import Title from '../../components/Text/Title';
import UserImg from '../../components/Layout/UserImg';
import UserProfile from '../../components/Layout/UserProfile';
import Slide from '../../components/Slide/Slide';
import Bold from '../../components/Text/Bold';
import Footer from '../Main/Footer';
import CommentSlides from"../../components/Slide/CommentSlides";
import Favorites from '../../components/Slide/Favorites';
import MyReviews from '../../components/Slide/MyReviews';

const MyPageWrap = styled.div`
  width:99vw;
  height:auto;
  .mypage-title{
    margin:5vh 0;
  }
  .slide-wrap{
    width:100%;
    margin:10vh 0 ;  
    .slide-title-wrap{
      width:65%;
      margin: auto;
      display:flex;
      flex-direction:row;
      align-items:center;
      padding-bottom:4vh;
      b{
        text-align:left;
        float:left;
        margin:0 1vw;
      }
      hr{
        width:85%;
        border:none;
        height:1.5px;
        background:#9CD5C2;
      }
    }
  }
`;

const ProfileWrap = styled.div`

  width:50%;
  height:auto;
  margin:0 auto;
  display:flex;
  flex-direction:row;
  justify-content: center;

  .user-img-wrap{
    width:50%;
    display:flex;
    flex-direction:row;
    align-items:center;
    justify-content:center;
  }
  input{
    font-size:16px;
    text-align:left;
    margin-bottom:1vh;
  }
}

`;

const Login = () => {
  return (
    <MyPageWrap>
      <Header></Header>
        <Title className="mypage-title">내 정보</Title>
      <ProfileWrap>
        <div className='user-img-wrap'>
          <UserImg>1</UserImg>
        </div>
        <UserProfile name="손흥민" nickname="sonny" email="abc@abc.com" num="010-1111-1111"></UserProfile>
      </ProfileWrap>
      <div className="slide-wrap">
        <div className='slide-title-wrap'>
          <Bold>내가 쓴 리뷰</Bold>
          <hr></hr>
        </div>
        <MyReviews></MyReviews>
      </div>
      <div className="slide-wrap">
        <div className='slide-title-wrap'>
          <Bold>내가 쓴 댓글</Bold>
          <hr></hr>
        </div>
        <CommentSlides></CommentSlides>
      </div>
      <div className="slide-wrap">
        <div className='slide-title-wrap'>
          <Bold>내가 찜한 곳</Bold>
          <hr></hr>
        </div>
        <Favorites></Favorites>
      </div>
    <Footer></Footer>
    </MyPageWrap>

  );
};

export default Login;
