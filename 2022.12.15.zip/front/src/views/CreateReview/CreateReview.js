import Header from "../Main/Header";
import styled from "styled-components";
import Title from "../../components/Text/Title";
import InputText from "../../components/Input/InputText";
import Tag from "../../components/Tag/Tag";
import Tags from "../../components/Tag/Tags";
import InputFile from "../../components/Input/InputFile";
import TextArea from "../../components/Input/TextArea";
import Button from "../../components/Button/Button";

const ReviewWrap = styled.div`
  padding-top:3vh;
  width:55%;
  height:auto;
  margin:0 auto;
  display:flex;
  flex-direction:column;
  justify-content:space-between;
  p, h2{
    text-align:left;
    width:10%;
    font-size:18px;
  }
  .outline{
    border:none;
    height:2px;
    background:#191919;
  }
  .gray{
    border:none;;
    height:1px;
    background:#cecece;
  }
  .title-wrap{
    h2{
      margin-bottom:1vh 0;
      font-size:25px;
    }
  }
  .bar-addr-wrap, .tag-wrap, .img-wrap, .review-wrap{
    width:100%;
    height:auto;

    display:flex;
    flex-direction:row;
    align-items:center;
    margin:3.5vh 0;
  }
  .bar-addr-wrap{
    justify-content:space-between;
    h2{
      width:20%;
    }
    .bar-name, .bar-addr{
      display:flex;
      flex-direction:row;
      justify-content:space-between;
      width:43%;
    }
    .bar-addr{
      h2{
        width:12%;
      }
    }
    .search-btn{
      width:10%;
      button{
        width:100%;
      }
    }
  }
  .tag-wrap{
    h2{
      width:10%;
    }
    div{
      width:90%;
    }
  }
  .img-wrap{
    
  }
  .review-wrap{
    textarea{
      height:20vh;
    }
  }
  .btn-wrap{
    width:100%;
    margin-top:2vh;
    font-size:30px;
    Button:first-child{
      width:40%;
      margin:0 1vw;
    }
    Button:last-child{
      width:40%;
      margin:0 1vw;
    }
  }
`;
const CheckBoxWrap = styled.div`
display:flex;
flex-direction:row;
align-items:center;
justify-content: space-evenly;
border:1px solid red;
.wrapper{
  
  :hover{
    border:1px solid blue;
  }
  input:checked + label:before{
    color:violet;
  }
}
  label{
    font-size:20px;
    :hover{
      border:1px solid green;
      color:red;
      cursor:pointer;
    }
  }
    
  
  
`;
function WriteReview(){
  return(
    <>
      <Header></Header>
      <ReviewWrap>
        <div className="title-wrap">
          <Title large>리뷰 등록</Title>
        </div>
          <hr className="outline"></hr>
        <div className="bar-addr-wrap">
          <div className="bar-name">
            <Title>상호명</Title>
            <InputText gray readOnly="true" placeholder="주소를 검색해주세요."></InputText>
          </div>
          <div className="bar-addr">
            <Title>주소</Title>
            <InputText gray readOnly="true" placeholder="주소를 검색해주세요."></InputText>
          </div>
          <div className="search-btn">
            <Button info>검색</Button>
          </div>
        </div>
        <hr className="gray"></hr>
        <div className="tag-wrap">
          <Title>태그</Title>
          <CheckBoxWrap>
                <div className="wrapper">
                  <input type='checkbox' name='와인' value="와인" id="와인"></input>
                  <label for="와인">와인</label>
                </div>
                <div className="wrapper">
                  <input type='checkbox' name='test1' id="test1"></input>
                  <label for="test1">test1</label>
                </div>
                <div className="wrapper">
                  <input type='checkbox' name='test2' id="test2"></input>
                  <label for="test2">test2</label>
                </div>
                <div className="wrapper">
                  <input type='checkbox' name='test3' id="test3"></input>
                  <label for="test3">test3</label>
                </div>
                <div className="wrapper">
                  <input type='checkbox' name='test4' id="test4"></input>
                  <label for="test4">test4</label>
                </div>
              </CheckBoxWrap>
        </div>
        <hr className="gray"></hr>
        <div className="img-wrap">
          <Title>사진</Title>
          <InputFile></InputFile>
        </div>
        <hr className="gray"></hr>
        <div className="review-wrap">
          <Title>리뷰</Title>
          <TextArea placeholder="30자 이상 작성 해주세요!"></TextArea>
        </div>
        <hr className="outline"></hr>
        <div className="btn-wrap">
          <Button info>등록</Button>
          <Button cancel>취소</Button>
        </div>
      </ReviewWrap>
    </>
  );
}

export default WriteReview;
