import '../../App.scss';
import styled from 'styled-components';
import Bold from '../../components/Text/Bold';
import Title from '../../components/Text/Title';
import Slide from '../../components/Slide/Slide';

const S3Wrap = styled.div`
width:99vw;
height:60vh;
display:flex;
flex-direction: column;
justify-content: center;
align-items:center;
`;

function Section3() {
  return (
    // <Wrapper>
    //   <S3Wrap>
    //     <Title style={{marginBottom:'60px'}}>최근 작성된 <Bold large>리뷰</Bold></Title>
    //     <Cards></Cards>
    //   </S3Wrap>
    // </Wrapper>
    <S3Wrap>
      <Title large style={{marginBottom:'60px'}}>최근 작성된 <Bold large>리뷰</Bold></Title>
      <Slide></Slide>
    </S3Wrap>
  );
}

export default Section3;
