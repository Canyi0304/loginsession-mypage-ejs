import '../../App.scss';
import styled from 'styled-components';
import { useNavigate } from "react-router-dom";
import Logo from '../../components/Logo/Logo';

const LogoWrap = styled.div`
  width:99vw;
  display:flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top:0.3rem;
  padding:0 1.6rem;
  align-items:center;
`;
const LoginWrap = styled.div`
  display:flex;
  flex-direction: row;
  align-items:center;
`;

const Login = styled.button`
  color:#191919;
  cursor:pointer;
  font-size:0.5rem;
  margin-left:1rem;
  border:none;
  background:none;
  :hover{
    color:#191919;
  }
  
`;
function Header() {
  const navigate = useNavigate();
  let goHome = () =>{
    navigate("/");
  }
  let goLogin = () =>{
    // alert('로그인버튼')
    navigate("/login");
  }
  let goMyPage = () =>{
    // alert('로그인버튼')
    navigate("/mypage");
  }
  return (
    <LogoWrap>
      <Logo onClick={goHome}>Logo</Logo>
      <LoginWrap>
        <Login onClick={goLogin}>Login</Login>
        <Login onClick={goMyPage}>My Page</Login>
      </LoginWrap>
    </LogoWrap>
  );
}

export default Header;
