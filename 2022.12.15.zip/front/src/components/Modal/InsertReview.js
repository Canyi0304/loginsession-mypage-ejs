
import { useState } from "react";
import styled from "styled-components";
import Modal from "./Modal";
import Button from "../Button/Button";

function InsertReview(){
    const [isOpen, setIsOpen] = useState(false);

    const onClickButton = () => {
      setIsOpen(true);
    };
  
    return (
      <ModalWrap>
        <Button info onClick={onClickButton}>리뷰 등록하기 +</Button>
        {isOpen && (<Modal
          open={isOpen}
          onClose={() => {
            setIsOpen(false);
          }}
        />)}
      </ModalWrap>
    );
  }
  
  
  
  const ModalWrap = styled.div`
    text-align: center;
    margin:0 auto;
    Button{
      width:100%;
    }
  `;

export default InsertReview;
